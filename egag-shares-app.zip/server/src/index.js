const express = require('express');
const cors = require('cors');
const { PrismaClient } = require('@prisma/client');
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');

const prisma = new PrismaClient();
const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes(prisma));
app.use('/api/projects', projectRoutes(prisma));

// Serve frontend in production when built
const path = require('path');
app.use(express.static(path.join(__dirname, '..', '..', 'client', 'dist')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', '..', 'client', 'dist', 'index.html'));
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
