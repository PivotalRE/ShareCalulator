const express = require('express');
const { authMiddleware } = require('../auth');
const { computeShare } = require('../utils/calc');

module.exports = (prisma) => {
  const router = express.Router();
  const protect = authMiddleware(prisma);

  router.post('/', protect, async (req, res) => {
    try {
      const { gross, salary, sharePercent, variablePercent } = req.body;
      const vpercent = typeof variablePercent === 'number' ? variablePercent : 0.2;
      const calc = computeShare(Number(gross), Number(salary), Number(sharePercent), Number(vpercent));
      const entry = await prisma.projectEntry.create({
        data: {
          userId: req.user.id,
          gross: Number(gross),
          salary: Number(salary),
          sharePercent: Number(sharePercent),
          variablePercent: Number(vpercent),
          computedShare: Number(calc.personShareAmount)
        }
      });
      res.json({ entry, calc });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.get('/', protect, async (req, res) => {
    const projects = await prisma.projectEntry.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: 'desc' } });
    const total = projects.reduce((s, p) => s + Number(p.computedShare), 0);
    res.json({ projects, total });
  });

  router.post('/complete', protect, async (req, res) => {
    const projects = await prisma.projectEntry.findMany({ where: { userId: req.user.id } });
    const total = projects.reduce((s, p) => s + Number(p.computedShare), 0);
    res.json({ message: `Congratulations, EGAG Solutions owes you PKR ${total.toFixed(2)}`, total });
  });

  return router;
};
