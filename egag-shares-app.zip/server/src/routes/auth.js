const express = require('express');
const bcrypt = require('bcrypt');
const { generateToken } = require('../auth');

module.exports = (prisma) => {
  const router = express.Router();

  router.post('/register', async (req, res) => {
    const { name, email, password, role } = req.body;
    try {
      const hash = await bcrypt.hash(password, 10);
      const user = await prisma.user.create({ data: { name, email, passwordHash: hash, role: role || 'user' } });
      const token = generateToken(user);
      res.json({ user: { id: user.id, name: user.name, email: user.email }, token });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) return res.status(401).json({ error: 'Invalid credentials' });
      const ok = await bcrypt.compare(password, user.passwordHash);
      if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
      const token = generateToken(user);
      res.json({ user: { id: user.id, name: user.name, email: user.email }, token });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  return router;
};
