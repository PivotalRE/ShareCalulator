function computeShare(gross, salary, sharePercent, variablePercent) {
  const after40 = gross - (0.4 * gross);
  const afterSalary = after40 - salary;
  const afterIncentives = afterSalary - (variablePercent * afterSalary);
  const personShareAmount = afterIncentives * (sharePercent / 100);
  return {
    after40,
    afterSalary,
    afterIncentives,
    personShareAmount
  };
}

module.exports = { computeShare };
