import React, { useState, useEffect } from 'react'
import axios from 'axios'
import ProjectForm from './components/ProjectForm'

const API = process.env.NODE_ENV === 'production' ? '' : 'http://localhost:4000';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('token'));
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')) || null);
  const [projects, setProjects] = useState([{ gross: 210000, salary: 45000, sharePercent: 50, variablePercent: 0.2 }]);
  const [total, setTotal] = useState(0);
  const [showDetail, setShowDetail] = useState(false);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (token) axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
  }, [token]);

  function addProject() {
    setProjects(p => [...p, { gross: 0, salary: 0, sharePercent: 0, variablePercent: 0.2 }]);
  }

  function updateProject(i, newValues) {
    setProjects(p => p.map((proj, idx) => idx === i ? { ...proj, ...newValues } : proj));
  }

  function removeProject(i) {
    setProjects(p => p.filter((_, idx) => idx !== i));
  }

  async function handleComplete() {
    try {
      let sum = 0;
      for (const proj of projects) {
        const res = await axios.post(`${API}/api/projects`, proj);
        sum += Number(res.data.calc.personShareAmount || res.data.entry.computedShare || 0);
      }
      setTotal(sum);
      setMessage(`Congratulations, EGAG Solutions owes you PKR ${sum.toFixed(2)}`);
    } catch (err) {
      console.error(err);
      alert('Error: make sure you are logged in and backend is running on the right URL');
    }
  }

  const [auth, setAuth] = useState({ email: '', password: '', name: '' });

  async function login() {
    const res = await axios.post(`${API}/api/auth/login`, { email: auth.email, password: auth.password });
    localStorage.setItem('token', res.data.token);
    localStorage.setItem('user', JSON.stringify(res.data.user));
    setToken(res.data.token); setUser(res.data.user);
  }

  async function register() {
    const res = await axios.post(`${API}/api/auth/register`, { name: auth.name, email: auth.email, password: auth.password });
    localStorage.setItem('token', res.data.token);
    localStorage.setItem('user', JSON.stringify(res.data.user));
    setToken(res.data.token); setUser(res.data.user);
  }

  return (
    <div className="min-h-screen bg-white text-gray-900 p-6 font-sans">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-2xl font-semibold mb-4">EGAG Shares Calculator</h1>

        {!token ? (
          <div className="p-4 border rounded-md">
            <h2 className="font-medium">Login (C-suite)</h2>
            <input className="w-full p-2 border my-2" placeholder="Email" value={auth.email} onChange={e=>setAuth(a=>({...a,email:e.target.value}))} />
            <input className="w-full p-2 border my-2" placeholder="Password" type="password" value={auth.password} onChange={e=>setAuth(a=>({...a,password:e.target.value}))} />
            <div className="flex gap-2">
              <button className="px-3 py-2 border rounded" onClick={login}>Login</button>
              <button className="px-3 py-2 border rounded" onClick={register}>Register</button>
            </div>
          </div>
        ) : (
          <div className="flex justify-between items-center mb-4">
            <div>Logged in as: <strong>{user?.name}</strong></div>
            <button className="text-sm" onClick={()=>{localStorage.removeItem('token'); localStorage.removeItem('user'); setToken(null); setUser(null);}}>Logout</button>
          </div>
        )}

        <div className="space-y-4">
          {projects.map((proj, i) => (
            <ProjectForm key={i} index={i} project={proj} onChange={nv=>updateProject(i,nv)} onRemove={()=>removeProject(i)} />
          ))}
        </div>

        <div className="mt-4 flex gap-2">
          <button className="px-4 py-2 border rounded" onClick={addProject}>Add Project</button>
          <button className="px-4 py-2 bg-green-600 text-white rounded" onClick={handleComplete}>Completed</button>
          <button className="px-4 py-2 border rounded" onClick={()=>setShowDetail(s=>!s)}>{showDetail ? 'Hide' : 'Unhide'} calculations</button>
        </div>

        {message && (
          <div className="mt-4 p-4 border rounded bg-green-50">
            <div className="font-semibold">{message}</div>
            {showDetail && (
              <div className="mt-2">
                <pre className="text-sm bg-white p-2 border rounded">Projects and breakdown are saved in your account. Use the Projects page to view details.</pre>
              </div>
            )}
          </div>
        )}

        {total > 0 && (
          <div className="mt-4 p-4 border rounded">
            <div>Total Payable: <strong>PKR {total.toFixed(2)}</strong></div>
          </div>
        )}
      </div>
    </div>
  )
}
