import React from 'react'

export default function ProjectForm({ project, onChange, index, onRemove }) {
  return (
    <div className="p-4 border rounded flex flex-col gap-2">
      <div className="flex justify-between">
        <div className="font-medium">Project #{index+1}</div>
        <button className="text-sm text-red-600" onClick={onRemove}>Remove</button>
      </div>
      <label>Gross Amount (PKR)
        <input className="w-full p-2 border mt-1" type="number" value={project.gross} onChange={e=>onChange({ gross: Number(e.target.value) })} />
      </label>
      <label>Salary (PKR)
        <input className="w-full p-2 border mt-1" type="number" value={project.salary} onChange={e=>onChange({ salary: Number(e.target.value) })} />
      </label>
      <label>Share % (0-100)
        <input className="w-full p-2 border mt-1" type="number" value={project.sharePercent} onChange={e=>onChange({ sharePercent: Number(e.target.value) })} />
      </label>
      <label>Variable % (e.g. 0.2 means 20%)
        <input className="w-full p-2 border mt-1" type="number" step="0.01" value={project.variablePercent} onChange={e=>onChange({ variablePercent: Number(e.target.value) })} />
      </label>
    </div>
  )
}
